package com.alibaba.bp.framework.plugin;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.io.StringReader;

import org.apache.commons.digester3.Digester;
import org.apache.commons.lang3.StringUtils;
import org.xml.sax.SAXException;



public class PluginParser {
    
    
    /**
     * the digester for parsing the XML.
     */
    private static Digester digester = null;

    static {
      
         digester = new Digester();
        // 不进行XML与相应的DTD的合法性验证
        digester.setValidating(false);
        // 不进行XML与相应的DTD的合法性验证
        digester.setValidating(false);

        // 当遇到<plugin>时创建一个Plugin对象，并将其放在栈顶
        digester.addObjectCreate("plugin", Plugin.class);

        // 设置<plugin>元素的子元素属性
        digester.addBeanPropertySetter("plugin/name", "name");
        digester.addBeanPropertySetter("plugin/version", "version");
        digester.addBeanPropertySetter("plugin/pluginPackage", "pluginPackage");
        digester.addSetProperties("plugin");

        // 当遇到<plugin>的子元素<bizcode>时创建一个BizCode对象，并将其放在栈顶。
        digester.addObjectCreate("plugin/bizcode", BizCode.class);

        digester.addBeanPropertySetter("plugin/bizcode/value", "value");

        digester.addBeanPropertySetter("plugin/bizcode/desc", "desc");

        digester.addSetProperties("plugin/bizcode");

        digester.addSetNext("plugin/bizcode", "addBizCode");
    }
    
    public static Plugin parse(File file) throws IOException, SAXException {
       
        return digester.parse(file);
    }

   
    public static Plugin parse( String text) throws IOException, SAXException {
        Reader reader = new StringReader(text);
        return digester.parse(reader);
    }

    /**
     *  parse the Plugin from text.
     *
     * @param is input stream.
     * @return the parsed PluginConfig.
     * @throws java.io.IOException
     * @throws org.xml.sax.SAXException
     */
    public static Plugin parse(InputStream is) throws IOException, SAXException {
        return digester.parse(is);
    }

 

    public static String getPluginClsPath(String pluginClass) {
        if (StringUtils.isEmpty(pluginClass)) {
            return StringUtils.EMPTY;
        }
        return StringUtils.substringBeforeLast(pluginClass, ".");
    }

}
