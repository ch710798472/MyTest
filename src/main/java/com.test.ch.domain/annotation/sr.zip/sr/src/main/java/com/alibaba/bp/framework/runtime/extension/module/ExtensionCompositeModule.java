package com.alibaba.bp.framework.runtime.extension.module;

import com.alibaba.bp.framework.runtime.extension.ExtensionLoader;
import com.alibaba.bp.framework.runtime.extension.impl.ExtensionLoaderImpl;
import com.google.inject.Binder;
import com.google.inject.Module;

/**
 *
 * @author bruce.zql
 * <p> 接口和实现的绑定
 */
public class ExtensionCompositeModule implements Module {

    @Override
    public void configure(Binder binder) {
        binder.bind(ExtensionLoader.class).to(ExtensionLoaderImpl.class);

    }

}
