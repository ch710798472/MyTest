package com.alibaba.bp.framework.exception;

public class ServiceNotFoundException extends RuntimeException
 {
    private static final long serialVersionUID = 1L;

    public ServiceNotFoundException(String message) {
        super(message);
    }

    public ServiceNotFoundException(String message, Throwable cause) {
        super(message, cause);
    }
}