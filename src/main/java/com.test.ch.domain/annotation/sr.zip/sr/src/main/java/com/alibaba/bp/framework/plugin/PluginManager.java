package com.alibaba.bp.framework.plugin;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.URL;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import com.alibaba.bp.framework.exception.PlatformException;
import com.alibaba.bp.framework.runtime.annotation.AdapterCfg;
import com.alibaba.bp.framework.runtime.annotation.Extension;
import com.alibaba.bp.framework.runtime.extension.ExtensionPoint;
import com.alibaba.bp.framework.runtime.extension.ExtensionRegistry;
import com.alibaba.bp.framework.runtime.extension.adapter.IAdaptable;
import com.alibaba.bp.framework.runtime.extension.adapter.IAdapterFactory;
import com.alibaba.bp.framework.runtime.extension.adapter.impl.AdapterManager;
import com.alibaba.bp.framework.runtime.extension.spec.ExtensionSpec;
import com.alibaba.bp.framework.utils.ClassLoaderUtil;
import com.alibaba.bp.framework.utils.ClassPathScanHandler;

import lombok.Getter;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang3.ClassUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.xml.sax.SAXException;

import com.google.common.collect.Lists;

public class PluginManager {

    private static final String                                                                 PLUGIN_FILE_NAME    = "plugin.xml";
    /**
     * LOGGER.
     */
    private static final Logger                                                                 LOGGER                  = LoggerFactory
                                                                                                                            .getLogger(PluginManager.class);
    /**
     * current PluginManager's instance.
     */
    private static volatile PluginManager                                                       instance                = null;

    /** **/
    private static volatile boolean                                                             initialized             = false;

    @Getter
    private static volatile boolean                                                             finished                = false;

    // 增加volatile是为了增加write memory barrier, 不要去掉
    private volatile List<Plugin>                                                               allPluginCache          = Lists
                                                                                                                            .newArrayList();

    private Map<String, Plugin>                                                                 bizCodePluginMap        = new HashMap<String, Plugin>();
    //bizType为key
    private Map<String, Map<Class<? extends ExtensionPoint>, Class<? extends IAdapterFactory>>> bizCodeToAdapterMetaMap = new HashMap<String, Map<Class<? extends ExtensionPoint>, Class<? extends IAdapterFactory>>>();

    /**
     * private.
     */
    private PluginManager() {

    }

    /**
     * @return the PluginManager instance.
     */
    public static PluginManager getInstance() {
        if (instance == null) {
            instance = new PluginManager();
            try {
                instance.init();
            } catch (Exception e) {
                throw new PlatformException(e);
            }
        }
        return instance;
    }

    public void init() throws Exception {
        synchronized (this) {
            while (initialized && !finished) {
                wait(1000);
            }
            if (initialized && finished)
                return;

            if (!initialized) {
                initialized = true;
                LOGGER.info("loading plugins...");
                String jarFilePath = PluginManager.class.getProtectionDomain().getCodeSource()
                    .getLocation().getFile();
                File path = new File(jarFilePath);
                try {
                    jarFilePath = java.net.URLDecoder.decode(path.getPath(), "UTF-8");
                } catch (UnsupportedEncodingException e) {
                    LOGGER.error(e.getMessage(), e);
                }
                int idx = jarFilePath.lastIndexOf(File.separator);
                String libPath = jarFilePath.substring(0, idx);
                LOGGER.warn("load plugins from lib path: " + libPath);
                /**
                 * load all plugin definition file class path.
                 */
                URL[] pluginFileURLs = ClassLoaderUtil.getResources(PLUGIN_FILE_NAME);
                instance.init(pluginFileURLs);

                finished = true;
            }
        }
    }

    public Plugin getPluginByBizCode(String bizType) {
        return bizCodePluginMap.get(bizType);
    }

    public List<Plugin> getAllPlugins() {
        return allPluginCache;
    }

    private void init(URL[] pluginFileURLs) {
        for (URL url : pluginFileURLs) {
            String context = getPluginContextFromURL(url); //plugin.xml文件
            LOGGER.warn("loaded plugin.xml:" + context);
            if (!StringUtils.isEmpty(context)) {
                Plugin plugin = null;
                try {

                    plugin = PluginParser.parse(context);
                } catch (IOException e) {
                    LOGGER.error("PluginParser.parse exception", e);
                } catch (SAXException e) {
                    LOGGER.error("PluginParser.parse exception", e);
                }
                initPlugin(plugin);

            }
        }

    }

    private void initPlugin(Plugin plugin) {
        if (plugin != null) {
            allPluginCache.add(plugin);
            List<BizCode> supportBizCodes = plugin.getSupportedBizCodes();
            if (!CollectionUtils.isEmpty(supportBizCodes)) {
                supportBizCodes.forEach(code -> {
                    bizCodePluginMap.put(code.getValue(), plugin);
                });
            }
            LOGGER.warn(plugin + "init finished");
            String pluginClassPackage = PluginParser.getPluginClsPath(plugin.getPluginPackage());

            List<BizCode> supportedBizCodes = plugin.getSupportedBizCodes();
            if (CollectionUtils.isNotEmpty(supportedBizCodes)) {
                for (BizCode bizCode : supportedBizCodes) {

                    ClassPathScanHandler handler = new ClassPathScanHandler();

                    Set<Class<?>> classSet = handler.getPackageAllClasses(pluginClassPackage, true)
                        .stream().filter(p -> null != p.getDeclaredAnnotation(Extension.class))
                        .collect(Collectors.toSet());
                    classSet.forEach(targetClass -> {

                        System.out.println("bizType:" + bizCode.getValue() + ",extensionClass:"
                                           + targetClass.getName());

                        Extension extension = targetClass.getDeclaredAnnotation(Extension.class);
                        String qualifiedName = targetClass.getName();
                        Class<? extends ExtensionPoint> extensionPointClass = extension
                            .extensionPoint();
                        System.out.println("extensionId:" + extension.extensionId()
                                           + "为空没有关系，可以根据Class去FactoryBean中根据类型获取beanId");
                        System.out.println("extensionPointId:" + extension.extensionPointId());
                        System.out.println("extensionPoint:" + extension.extensionPoint());
                        ExtensionSpec spec = ExtensionSpec.of(bizCode.getValue(),
                            extension.extensionPointId(), extension.domain(),
                            extension.extensionId(), qualifiedName, extensionPointClass,
                            extension.getPriority());
                        ExtensionRegistry.INSTANCE.register(spec);

                    });

                    scanAdapterExt(bizCode, pluginClassPackage);
                }
            }
        }
    }

  

    private void scanAdapterExt(BizCode bizCode, String pluginClassPackage) {

        ClassPathScanHandler handler = new ClassPathScanHandler();
        Set<Class<?>> classSet = handler.getPackageAllClasses(pluginClassPackage, true).stream()
            .filter(p -> null != p.getDeclaredAnnotation(AdapterCfg.class))
            .collect(Collectors.toSet());
        classSet
            .forEach(targetClass -> {

                System.out.println("------------------------Factory start---------------");
                AdapterCfg template = targetClass.getDeclaredAnnotation(AdapterCfg.class);
                Class<? extends IAdaptable> adaptableType = template.adaptableType();
                System.out.println("FactoryClsName:" + targetClass.getName());
                Class<? extends ExtensionPoint>[] extensionPoints = template.extensionPoints();
                if (extensionPoints == null || template.bizCodes() == null) {
                    return;
                }
                for (String code : template.bizCodes()) {

                    System.out.println("supportedBizCode:" + code);
                    Map<Class<? extends ExtensionPoint>, Class<? extends IAdapterFactory>> extensionPointClassToFactory = new HashMap<>();
                    Map<Class<? extends IAdaptable>, Class<? extends IAdapterFactory>> adaptableClassToFactory = new HashMap<>();
                    for (Class<? extends ExtensionPoint> inf : extensionPoints) {
                        //PurchaseItemRecordExtensionPoints
                        System.out.println("extensionPointClass:" + inf.getName());
                        
                        if (ClassUtils.isAssignable( targetClass, IAdapterFactory.class)) {
                            //tagetClass是否是IAdapterFactory的接口实现
                            IAdapterFactory factory = null;
                            try {
                                factory = (IAdapterFactory) targetClass.newInstance();
                                extensionPointClassToFactory.put(inf, factory.getClass());
                                adaptableClassToFactory.put(adaptableType, factory.getClass());
                                //被扩展的类名与Factory的Map添加
                                AdapterManager.getInstance().registerAdapters(bizCode.getValue(),
                                    factory, adaptableType, inf);
                            } catch (Exception e) {
                                LOGGER.error("targetClass instantiation exception", e);
                            }
                        }
                    }
                    bizCodeToAdapterMetaMap.put(code, extensionPointClassToFactory);
                }

                System.out.println("------------------------Factory end---------------");

            });

    }
    

    private String getPluginContextFromURL(URL url) {
        try {
            BufferedReader br = new BufferedReader(new InputStreamReader(url.openStream()));
            String line;
            StringBuilder context = new StringBuilder();
            while ((line = br.readLine()) != null) {
                context.append(line);
            }
            return context.toString();
        } catch (Exception ex) {
            return null;
        }

    }

    public Map<String, Map<Class<? extends ExtensionPoint>, Class<? extends IAdapterFactory>>> getBizCodeToAdapterMetaMap() {
        return bizCodeToAdapterMetaMap;
    }

}
