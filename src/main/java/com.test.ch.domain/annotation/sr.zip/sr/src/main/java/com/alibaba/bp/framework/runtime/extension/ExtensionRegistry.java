package com.alibaba.bp.framework.runtime.extension;

import java.util.List;
import java.util.Map;

import com.alibaba.bp.framework.runtime.extension.impl.DefaultExtensionRegistry;
import com.alibaba.bp.framework.runtime.extension.spec.ExtensionSpec;

/**
 * @author bruce.zql
 *
 */
public interface ExtensionRegistry {
    
    ExtensionRegistry INSTANCE = DefaultExtensionRegistry.getInstance();

    void register(ExtensionSpec spec);

    /**
     * @return a map  which key is the extensionpoint interface class
     */
    Map<Class<? extends ExtensionPoint>, List<ExtensionSpec>> getAll();
    

    List<ExtensionSpec> getExtensionSpecList(Class<? extends ExtensionPoint> type);
    
    
    List<ExtensionSpec> getExtensionSpecList(String extensionPointId);
    
    
    


}
