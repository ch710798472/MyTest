package com.alibaba.bp.framework.runtime.extension.adapter;


public interface IAdapterFactory {

    /**
     * 实现类要根据adapterType的具体类型生产出具体的适配器
     * 例如：<blockquote><pre>
     * ItemSDOPropertiesSourceAdapterFactory：
     * if(adapterType == IPropertySource.class){
     *   return new ItemSDOPropertySource((ItemSDO)adaptableObject);
     *  }
     * </pre></blockquote>
     * Returns an object which is an instance of the given class associated with the given object. Returns null if no such object can be found.
     * @param adaptableObject the adaptable object being queried (usually an instance of IAdaptable)
     * @param adapterType the type of adapter to look up
     * @return a object of the given adapter type, or null if this adapter factory does not have an adapter of the given type for the given object
     */
     <T> T getAdapter(Object adaptableObject, Class<T> adapterType);

    /**
     * Returns the collection of adapter types handled by this factory.
       This method is generally used by an adapter manager to discover which adapter types are supported, in advance of dispatching any actual getAdapter requests.
     * @return
     */
    Class<?>[] getAdapterList();

}
