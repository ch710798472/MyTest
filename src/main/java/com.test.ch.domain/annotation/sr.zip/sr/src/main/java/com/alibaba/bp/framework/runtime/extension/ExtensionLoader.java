package com.alibaba.bp.framework.runtime.extension;

import java.util.Optional;

import com.alibaba.bp.framework.runtime.extension.spec.ExtensionSpec;

public interface ExtensionLoader {
    
    
    /**
     * @param bizCode
     * @param type
     * @return
     */
    Optional<ExtensionSpec> loadExtension(String bizCode, Class<? extends ExtensionPoint> type);
    
    /**
     * @param bizCode
     * @param extensionPointId
     * @return
     */
    Optional<ExtensionSpec> loadExtension(String bizCode, String extensionPointId);
    
    
    
 

}
