package com.alibaba.bp.framework.plugin;

public class BizCode {
    
    private String value;
    
    private String desc;

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    @Override
    public String toString() {
        return "BizCode [value=" + value + ", desc=" + desc + "]";
    }
    
    

}
