package com.alibaba.bp.framework.runtime.extension.adapter;

import com.alibaba.bp.framework.runtime.extension.ExtensionPoint;

/**
 * @author bruce.zql
 * Inspired by eclipse
 *
 */
public interface IAdaptable {
    
   /**
    * Returns an object which is an instance of the given class associated with this object. 
    * Returns null if no such object can be found.
    * @param adapter 要适配到的接口类
    * @return
   */
    ExtensionPoint getAdapter(String bizCode, Class<? extends ExtensionPoint> adapter);

}
