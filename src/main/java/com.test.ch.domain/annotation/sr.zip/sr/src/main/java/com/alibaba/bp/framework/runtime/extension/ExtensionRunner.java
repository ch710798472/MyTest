package com.alibaba.bp.framework.runtime.extension;

@FunctionalInterface
public interface ExtensionRunner {
    
    <R> R executeExtension(ExtensionPoint extensionPoint);

}
