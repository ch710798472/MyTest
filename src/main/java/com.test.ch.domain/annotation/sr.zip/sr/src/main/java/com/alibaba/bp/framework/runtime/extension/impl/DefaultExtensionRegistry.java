package com.alibaba.bp.framework.runtime.extension.impl;

import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import com.alibaba.bp.framework.runtime.extension.ExtensionRegistry;
import com.alibaba.bp.framework.runtime.extension.spec.ExtensionSpec;
import org.apache.commons.lang3.StringUtils;

import com.alibaba.bp.framework.runtime.extension.ExtensionPoint;
import com.google.common.collect.Lists;


/**
 * 注册扩展点的实现类
 * @author bruce.zql
 *
 */
public class DefaultExtensionRegistry implements ExtensionRegistry {

    private static volatile DefaultExtensionRegistry                  instance                = null;

    private Map<Class<? extends ExtensionPoint>, List<ExtensionSpec>> extensionPointToMetaMap = new ConcurrentHashMap<>();
    //extensionPointId到实现类的映射
    private Map<String, List<ExtensionSpec>>                          identifyCache           = new ConcurrentHashMap<String, List<ExtensionSpec>>();

    private DefaultExtensionRegistry() {

    }

    public static DefaultExtensionRegistry getInstance() {
        if (instance == null) {
            synchronized (DefaultExtensionRegistry.class) {
                if (instance == null) {
                    instance = new DefaultExtensionRegistry();
                }
            }
        }
        return instance;
    }

    @Override
    public void register(ExtensionSpec spec) {
        if (!StringUtils.isEmpty(spec.getExtensionPointId())) {

            List<ExtensionSpec> extensionSpecList = identifyCache.computeIfAbsent(
                spec.getExtensionPointId(), k -> Lists.newArrayList());
            extensionSpecList.add(spec);
            //sorted by priority
            extensionSpecList.sort((a, b) -> a.getPriority() - b.getPriority());

        }
        // construct a new object serving as an initial mapped value 
        List<ExtensionSpec> extensionSpecList = extensionPointToMetaMap.computeIfAbsent(
            spec.getExtensionPoint(), k -> Lists.newArrayList());
        extensionSpecList.add(spec);
        //sorted by priority
        extensionSpecList.sort((a, b) -> a.getPriority() - b.getPriority());

    }

    @Override
    public Map<Class<? extends ExtensionPoint>, List<ExtensionSpec>> getAll() {
        return extensionPointToMetaMap;
    }

    @Override
    public List<ExtensionSpec> getExtensionSpecList(Class<? extends ExtensionPoint> type) {

        return extensionPointToMetaMap.get(type);
    }

    @Override
    public List<ExtensionSpec> getExtensionSpecList(String extensionPointId) {

        return identifyCache.get(extensionPointId);

    }
}
