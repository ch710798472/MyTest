package com.alibaba.bp.framework.runtime.extension.spec;

import com.alibaba.bp.framework.runtime.extension.ExtensionPoint;

import lombok.Getter;
import lombok.Setter;

/**
 * @author bruce.zql
 * Extension MetaData 
 * 扩展元数据Spec
 *
 */


public class ExtensionSpec extends BaseSpec{
    
    @Getter
    @Setter
    private String extensionPointId;
    
    
    /**
     * the unique identifier of the extension 
     */
    @Getter
    @Setter
    private String extensionId;
    
    @Getter
    @Setter
    private Class<? extends ExtensionPoint> extensionPoint;
    
    
    @Getter
    @Setter
    private String quanlifiedName;
    
    @Getter
    @Setter
    private String domainCode;
    
    @Getter
    @Setter
    private Integer priority;
    
    

    
    public static ExtensionSpec of(String bizCode,String extensionPointId, String domainCode, String extensionId,String quanlifiedName,
                                   Class<?  extends ExtensionPoint> extensionPoint, Integer priority) {
        ExtensionSpec spec = new ExtensionSpec();
        spec.setBizCode(bizCode);
        spec.setDomainCode(domainCode);
        spec.setPriority(priority);
        spec.setExtensionPointId(extensionPointId);
        spec.setQuanlifiedName(quanlifiedName);
        spec.setExtensionId(extensionId);
        spec.setExtensionPoint(extensionPoint);
        return spec;
    }
    
    
    public static ExtensionSpec of(String bizCode,String extensionPointId, String domainCode, String extensionId,String quanlifiedName,
                                   Class<?  extends ExtensionPoint> extensionPoint, Integer priority,String name, String desc) {
        ExtensionSpec spec = new ExtensionSpec();
        spec.setBizCode(bizCode);
        spec.setDomainCode(domainCode);
        spec.setName(name);
        spec.setDesc(desc);
        spec.setPriority(priority);
        spec.setExtensionPointId(extensionPointId);
        spec.setQuanlifiedName(quanlifiedName);
        spec.setExtensionId(extensionId);
        spec.setExtensionPoint(extensionPoint);
        return spec;
    }

}
