package com.alibaba.bp.framework.facade;



import com.alibaba.bp.framework.runtime.extension.ExtensionRegistry;
import com.alibaba.bp.framework.runtime.extension.adapter.impl.AdapterManager;
import com.alibaba.bp.framework.runtime.extension.module.ExtensionCompositeModule;
import com.alibaba.bp.framework.runtime.extension.ExtensionLoader;
import com.alibaba.bp.framework.runtime.extension.adapter.IAdapterManager;

import com.google.inject.Guice;
import com.google.inject.Injector;

public final class BusinessPlatform {

    private BusinessPlatform() {

    }

    public static BusinessPlatform instance = new BusinessPlatform();
    
    private static Injector injector = Guice.createInjector(new ExtensionCompositeModule());

    public static ExtensionLoader getExtensionLoader() {
        return injector.getInstance(ExtensionLoader.class);
    }
    
    public static IAdapterManager getAdapterManager() {
        return AdapterManager.getInstance();
    }
    
    public static ExtensionRegistry getExtensionRegistry() {
        return ExtensionRegistry.INSTANCE;
    }

}
