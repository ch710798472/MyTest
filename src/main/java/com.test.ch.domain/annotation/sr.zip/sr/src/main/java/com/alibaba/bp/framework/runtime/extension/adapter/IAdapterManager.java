package com.alibaba.bp.framework.runtime.extension.adapter;

import com.alibaba.bp.framework.runtime.extension.ExtensionPoint;

/**
 * @author bruce.zql
 * <p>
 * An adapter manager maintains a registry of adapter factories. Clients directly invoke methods on an adapter manager to register and unregister adapters. 
 * All adaptable objects (that is, objects that implement the IAdaptable interface) funnel IAdaptable.getAdapter invocations to their adapter manager's IAdapterManger.getAdapter method. 
 * The adapter manager then forwards this request unmodified to the IAdapterFactory.getAdapter method on one of the registered adapter factories.
   Adapter factories can be registered programmatically using the registerAdapters method. 
   Alternatively, they can be registered declaratively using extension point. 
   Factories registered with this extension point will not be able to provide adapters until their corresponding plugin has been activated.
   </p>
 *
 */
public interface IAdapterManager {

    /**
     * @param adaptable  the adaptable object being queried (usually an instance of IAdaptable)
     * @param adapterType the type of adapter to look up
     * @return
     */
    ExtensionPoint getAdapter(String bizCode, Object adaptable, Class<? extends ExtensionPoint> adapterType);

  

    boolean hasAdapter(String bizCode,Object adaptable, String adapterTypeName);

    /**
     * 注册这个接口对应的具体工厂
     * Registers the given adapter factory as extending objects of the given type.
       If the type being extended is a class, the given factory's adapters are available on instances of that class and any of its subclasses. 
       If it is an interface, the adapters are available to all classes that directly or indirectly implement that interface.
     * @param factory  the adapter factory
     * @param adaptable the type being extended
     */
    void  registerAdapters(String bizCode,IAdapterFactory factory, Class<? extends IAdaptable> adaptable,Class<? extends ExtensionPoint> adapterType);

}
