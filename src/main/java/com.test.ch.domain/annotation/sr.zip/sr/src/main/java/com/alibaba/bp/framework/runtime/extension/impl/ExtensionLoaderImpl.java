package com.alibaba.bp.framework.runtime.extension.impl;

import java.util.List;
import java.util.Optional;

import com.alibaba.bp.framework.runtime.extension.ExtensionPoint;
import com.alibaba.bp.framework.runtime.extension.spec.ExtensionSpec;
import com.alibaba.bp.framework.runtime.extension.ExtensionLoader;
import com.alibaba.bp.framework.runtime.extension.ExtensionRegistry;

import org.apache.commons.collections.CollectionUtils;

import com.google.inject.Singleton;

@Singleton
public class ExtensionLoaderImpl implements ExtensionLoader {
    

    @Override
    public Optional<ExtensionSpec> loadExtension(String bizCode, Class<? extends ExtensionPoint> type) {
        List<ExtensionSpec> specs= ExtensionRegistry.INSTANCE.getExtensionSpecList(type);
        if(CollectionUtils.isEmpty(specs)){
            return null;
        }
        ExtensionSpec extensionSpec=specs.stream().filter(spec->spec.getBizCode().equals(bizCode)).findFirst().orElse(null);
        return Optional.ofNullable(extensionSpec);
    }

    @Override
    public Optional<ExtensionSpec> loadExtension(String bizCode, String extensionPointId) {
        List<ExtensionSpec> specs= ExtensionRegistry.INSTANCE.getExtensionSpecList(extensionPointId);
        if(CollectionUtils.isEmpty(specs)){
            return Optional.empty();
        }
        ExtensionSpec extensionSpec=specs.stream().filter(spec->spec.getBizCode().equals(bizCode)).findFirst().orElse(null);
        return Optional.ofNullable(extensionSpec);
    }
    
    
    

   

}
