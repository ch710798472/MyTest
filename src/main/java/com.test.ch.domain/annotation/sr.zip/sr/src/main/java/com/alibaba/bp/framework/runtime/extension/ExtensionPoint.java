package com.alibaba.bp.framework.runtime.extension;
/**
 * 
 * <p>Marker interface that designates extensible components
 * in bp that can be implemented by plugins.<br>　
 * <p>
 * See respective interfaces/classes for more about how to register custom
 * implementations to bp. See {@link Extension} for how to have
 * bp auto-discover your implementations.
 * <p>

 * @author bruce.zql
 * @since 2016.10.15
 * @see Extension
 */
public interface ExtensionPoint {
   
}