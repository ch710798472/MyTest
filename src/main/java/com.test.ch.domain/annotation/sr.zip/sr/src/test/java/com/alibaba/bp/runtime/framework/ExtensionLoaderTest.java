package com.alibaba.bp.runtime.framework;

import org.junit.Test;

public class ExtensionLoaderTest {
    
    @Test
    public void test_load_extensions(){
        
    }

}
