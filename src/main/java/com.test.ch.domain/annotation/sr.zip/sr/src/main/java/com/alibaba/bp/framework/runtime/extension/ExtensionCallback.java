package com.alibaba.bp.framework.runtime.extension;

import java.util.function.Function;

/**
 * @author bruce.zql
 * <p>使用callback desgin pattern, 这种模式可以有效减少扩展点实现类的个数，对于简单的扩展，可以直接使用lambda表达式实现
 * <p>通过回调的方式执行扩展，使得寻找实现类和执行扩展点的代码可以通用化，避免重复写模板代码
 * @param <T> an implementation of interface ExtensionPoint
 * @param <R> return value of the interface ExtensionPoint
 */
public interface ExtensionCallback<T extends ExtensionPoint,R> extends Function<T, R> {

}
