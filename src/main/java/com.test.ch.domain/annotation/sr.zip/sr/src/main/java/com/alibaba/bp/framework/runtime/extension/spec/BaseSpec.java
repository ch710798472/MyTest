package com.alibaba.bp.framework.runtime.extension.spec;

import lombok.Getter;
import lombok.Setter;


/**
 * @author bruce.zql
 * 
 * specification for describing meta info
 *
 *
 */
public abstract class BaseSpec {
    
    @Getter
    @Setter
    private String name;
    
    @Getter
    @Setter
    private String desc;
    
    @Getter
    @Setter
    private String bizCode;

}
