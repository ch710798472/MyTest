package com.alibaba.bp.framework.runtime.extension;

import lombok.Getter;
import lombok.Setter;

public enum DomainCode {

    SETTLEL("com.alibaba.bp.settle","settle");
    
    @Getter
    @Setter
    private String code;
    
    
    @Getter
    @Setter
    private String desc;
    
     DomainCode(String code, String desc){
        this.code=code;
        this.desc=desc;
    }

}
