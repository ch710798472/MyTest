package com.alibaba.bp.framework.plugin;

import java.util.ArrayList;
import java.util.List;

public class Plugin {

    private String        name;

    private String        version;
    
    private String        pluginPackage;

    private List<BizCode> supportedBizCodes = new ArrayList<BizCode>();

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }
    
    

    public String getPluginPackage() {
        return pluginPackage;
    }

    public void setPluginPackage(String pluginPackage) {
        this.pluginPackage = pluginPackage;
    }

    public List<BizCode> getSupportedBizCodes() {
        return supportedBizCodes;
    }

    public void addBizCode(BizCode e) {
        supportedBizCodes.add(e);
    }

    @Override
    public String toString() {
        return "Plugin [name=" + name + ", version=" + version + ", pluginClass=" + pluginPackage
               + ", supportedBizCodes=" + supportedBizCodes + "]";
    }
    
    

}
