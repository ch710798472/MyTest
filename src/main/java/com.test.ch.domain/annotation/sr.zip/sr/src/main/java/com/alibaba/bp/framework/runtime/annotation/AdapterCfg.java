package com.alibaba.bp.framework.runtime.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import com.alibaba.bp.framework.runtime.extension.ExtensionPoint;
import com.alibaba.bp.framework.runtime.extension.adapter.IAdaptable;

/**
 * @author bruce.zql
 * used to associate Factory Class with bizCode and AdapterType Class
 * 适配器工厂类上面的注解
 */
@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.TYPE})

public @interface AdapterCfg {
    
    String[] bizCodes() default "";
    
    Class<? extends IAdaptable> adaptableType();

    /**
     * ExtensionPoint的子接口就是adapterType
     * @return interface Classes to be extended
     */
    Class<? extends ExtensionPoint>[] extensionPoints();
}
