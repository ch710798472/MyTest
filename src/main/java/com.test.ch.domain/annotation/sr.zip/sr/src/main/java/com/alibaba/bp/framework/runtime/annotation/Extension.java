package com.alibaba.bp.framework.runtime.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import com.alibaba.bp.framework.runtime.extension.ExtensionPoint;

/**
 * @author bruce.zql
 * 
 *
 */
@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.TYPE,ElementType.METHOD})
public @interface Extension {
    

    /**
     * <p>Spec: "bp.domainName.{extensionPointName}"
     * @return the unique identifier of the extension point
     */
    String extensionPointId();
    
    
    /**
     * @return the unique identifier of the extension 
     * <p>(use Spring beanId if extensionId is empty)
     */
    String extensionId() default "";
    
    
  
    int getPriority() default 0;

   
    Class<? extends ExtensionPoint> extensionPoint();
    
    
    String name() default "";
    
    
    String desc() default "";
    
    String domain() default "bp";

}
