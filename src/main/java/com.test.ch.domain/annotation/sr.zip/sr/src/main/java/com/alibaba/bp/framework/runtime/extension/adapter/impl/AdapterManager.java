package com.alibaba.bp.framework.runtime.extension.adapter.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import com.alibaba.bp.framework.runtime.extension.ExtensionPoint;
import com.alibaba.bp.framework.runtime.extension.adapter.IAdaptable;
import com.alibaba.bp.framework.runtime.extension.adapter.IAdapterFactory;
import com.alibaba.bp.framework.runtime.extension.adapter.IAdapterManager;

/**
 * @author bruce.zql
 * 
 * This class is the standard implementation of <code>IAdapterManager</code>. It provides
 * fast lookup of property values with the following semantics:
 * <ul>
 * <li>At most one factory will be invoked per property lookup 每次lookup最多有一个factory被调用
 * <li>If multiple installed factories provide the same adapter, only the first found in
 * the search order will be invoked. 如果符合条件的factory有多个，则只返回第一个
 * <li>The search order from a class with the definition <br>
 * <code>class X extends Y implements A, B</code><br> is as follows: <il>
 * <li>the target's class: X
 * <li>X's superclasses in order to <code>Object</code>
 * <li>a breadth-first traversal of the target class's interfaces in the order returned by
 * <code>getInterfaces</code> (in the example, A and its superinterfaces then B and its
 * superinterfaces) </il>
 * demo:
 * <factory
        adaptableType="org.eclipse.core.resources.ItemSDO" 
        class="org.taobao.core.adapters.properties.ItemSDOPropertiesSourceAdapterFactory"> 
     <adapter
           type="com.taobao.buy.properties.IPropertySource"> 
     </adapter>
  </factory>
 * </ul>
 * 根据需要adaptableClassName和BizCode可以搜索到IAdaptorFactory
 * @see IAdapterFactory
 * @see IAdapterManager
 */


public final class AdapterManager implements IAdapterManager {

    /**
     * 一个AdaptableClass指实现了IAdaptable接口的实现类，对应一个或者多个适配器
     * Map of factories, keyed by <code>String</code>, fully qualified class name of
     * the adaptable class that the factory provides adapters for. Value is a <code>List</code>
     * of <code>IAdapterFactory</code>.
     */
    protected Map<String, List<IAdapterFactory>>        adaptableClsToFactoryCache     = new ConcurrentHashMap<String, List<IAdapterFactory>>();

    // (bizCode -> (adaptable class name -> factory instance))
    protected Map<String, Map<String, IAdapterFactory>> bizCodeToAdaptableClsNameFactory = new ConcurrentHashMap<String, Map<String, IAdapterFactory>>();

    /** 
     * 一个类被扩展后，可能有多个适配器，每个适配器对应一个IAdapterFactory
     * 适配器类是指新接口的实现类全路径名
     * Cache of adapters for a given adaptable class. Maps String  -> Map
     * (adaptable class name -> (adapter class name -> factory instance))
     */

    private static final AdapterManager                 singleton                      = new AdapterManager();

    public static AdapterManager getInstance() {
        return singleton;
    }

    /**
     * Private constructor to block instance creation.
     */
    private AdapterManager() {

    }

    @Override
    public ExtensionPoint getAdapter(String bizCode, Object adaptable,
                                     Class<? extends ExtensionPoint> adapterType) {
        
        IAdapterFactory factory = getFactory(bizCode, adaptable.getClass(), adapterType);

        if (factory != null) {
            return factory.getAdapter(adaptable, adapterType);
        }
        return null;
    }

    @Override
    public void registerAdapters(String bizCode, IAdapterFactory factory,
                                 Class<? extends IAdaptable> adaptable, Class<? extends ExtensionPoint> adapterType) {

        List<IAdapterFactory> factoryList = adaptableClsToFactoryCache.computeIfAbsent(
            adaptable.getName(), k -> new ArrayList<IAdapterFactory>());
        factoryList.add(factory);
        Map<String,IAdapterFactory> adaptaleClsNameToFactory=new HashMap<>();
        adaptaleClsNameToFactory.put(adaptable.getName(), factory);
        bizCodeToAdaptableClsNameFactory.put(bizCode, adaptaleClsNameToFactory);
    }

    /**
      * Gets the adapter factory installed for objects of class <code>extensibleClass</code>
      * which defines adapters of type <code>adapter</code>. If no such factories
      * exists, returns null.
      */
    private synchronized IAdapterFactory getFactory(String bizCode, Class<?> adaptable,
                                                    Class<? extends ExtensionPoint> adapterTypeClass) {

        Map<String, IAdapterFactory> table = bizCodeToAdaptableClsNameFactory.get(bizCode);
        if (table != null) {
            return table.get(adaptable.getName());
        }

        return null;
    }

    @Override
    public boolean hasAdapter(String bizCode, Object adaptable, String adapterTypeName) {

        Map<String, IAdapterFactory> table = bizCodeToAdaptableClsNameFactory.get(bizCode);
        if (table != null) {
            return table.get(adaptable.getClass().getName()) != null ? true : false;
        }

        return false;
    }

}
